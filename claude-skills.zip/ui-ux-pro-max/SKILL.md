---
name: ui-ux-pro-max
description: Design intelligence toolkit with searchable databases of 50+ UI styles, 97 color palettes, 57 font pairings, 99 UX guidelines, and 25 chart types across multiple stacks. Use when building new UI, choosing design direction, auditing UX, or generating a persistent design system for a project. Triggers on requests like "design a landing page", "what style fits this app", "color palette for fintech", "UX review", "build a dashboard", or "create a design system".
allowed-tools: Read, Write, Edit, Bash, Glob, Grep
---

# UI/UX Pro Max

Design intelligence toolkit. Always run `--design-system` first for any new page or component. Supplement with `--domain` searches for specific needs.

## Prerequisites

```bash
python3 --version || python --version
```

## Step 1: Analyze Requirements

Extract from the user's request:
- **Product type**: SaaS, e-commerce, portfolio, entertainment, tool, service
- **Style keywords**: minimal, dark, vibrant, luxury, editorial, brutalist, organic
- **Stack**: react, nextjs, html-tailwind, vue, svelte, react-native, flutter, shadcn

## Step 2: Generate Design System (REQUIRED)

```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<product_type> <industry> <keywords>" --design-system [-p "Project Name"]
```

Example:
```bash
python3 skills/ui-ux-pro-max/scripts/search.py "beauty spa wellness" --design-system -p "Serenity Spa"
```

### Persist for multi-page projects:

```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<query>" --design-system --persist -p "Project Name"
```

Creates `design-system/MASTER.md` (global) and `design-system/pages/` (page overrides).

## Step 3: Detailed Searches

```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<keyword>" --domain <domain>
```

| Domain | Use For |
|--------|---------|
| `product` | Product type patterns |
| `style` | UI styles, glassmorphism, brutalism, dark mode |
| `color` | Color palettes by industry |
| `typography` | Font pairings (Google Fonts) |
| `landing` | Page structure, CTA strategies |
| `chart` | Chart types and library recommendations |
| `ux` | Best practices and anti-patterns |
| `react` | React/Next.js performance rules |

## Step 4: Stack Guidelines

```bash
python3 skills/ui-ux-pro-max/scripts/search.py "<keyword>" --stack <stack>
```

Available stacks: `html-tailwind`, `react`, `nextjs`, `astro`, `vue`, `svelte`, `shadcn`, `react-native`, `flutter`, `swiftui`

## Pre-Delivery Checklist

- No emoji as icons (use SVG/vector)
- All touch targets ≥ 44×44pt
- Primary text contrast ≥ 4.5:1 (light and dark)
- Safe areas respected on mobile
- Tested on 375px small screen
- Reduced-motion respected
- Consistent spacing rhythm (4/8dp)
- Borders visible in both light and dark mode
