---
name: project-brief
description: Use when a user wants to create, formalize, or update a project brief: a structured reference document for a project's scope, roadmap, decisions, tech stack, and brand. Triggers on "brief document" or "brief dokument". Supports JSX, HTML, PDF, and Markdown output.
---

# Project Brief Creator

A project brief is the living reference for a whole project: detailed enough for a developer (or Claude Code) to grasp full scope, readable enough for the owner to use daily.

Modeled after the **Venio brief template** — dark header, collapsible sections, accordion roadmap, color-coded phases, alert callouts, key-value rows.

Build understanding through natural conversation first, never rush to create. The four phases below run in order.

---

## Language

The brief follows the language of the conversation:
- If the user writes in Serbian → brief is in Serbian (technical English terms like "render-on-demand", "tech stack", "checkout" stay in English where natural).
- If the user writes in English → brief is fully in English.

Never mix languages arbitrarily. Match the user.

---

## Phase 1 — Information Gathering

Collect naturally through conversation. Do NOT ask for everything at once. Track what's known and what's missing.

### Required before creating:
- [ ] Project / brand name
- [ ] What the product or service does (core concept, 1-2 sentences)
- [ ] Target audience / market
- [ ] Primary approach (tech stack, methodology, or tools — if relevant)
- [ ] At least a rough list of phases, steps, or milestones

### Useful — ask if not mentioned:
- [ ] Brand colors (hex values)
- [ ] Brand fonts
- [ ] Key decisions already confirmed
- [ ] Revenue model or monetization plan
- [ ] Hosting, domain, or infrastructure choices

### Optional — include if available:
- [ ] Competitor context or positioning
- [ ] Budget or cost constraints
- [ ] Timeline or launch target

---

## Phase 2 — Readiness Check

When the minimum required info is gathered, ask:

> "Mislim da imamo dovoljno da napravimo solid brief. Da li si spreman, ili ima još nečeg što bi dodao pre nego što krenem?"

At this point also ask (if not already known):

1. **Format**: JSX, HTML, PDF, ili Markdown?
2. **Brand boje**: Imaš li hex vrednosti? Ako ne, koristim default paletu.
3. **Brand fontovi**: Imaš li specifične fontove? Ako ne, koristim default.
4. **Verzija/naziv fajla**: Npr. `venio-brief-v1.0` — ili da ja odredim?

---

## Phase 3 — Creation

Follow the visual specs below for the chosen format. Save the output as a file: in claude.ai, to `/mnt/user-data/outputs/` then call `present_files`; in Claude Code, to the project directory. All formats are download files — do NOT render as a React artifact.

---

## Phase 4 — Iteration

After presenting, offer to add, adjust, or expand any section.

**Trigger update workflow when:**
- User says "ažuriraj brief", "dodaj u brief", "izmeni", "update brief"
- Accumulated changes are substantial (new phases, renamed sections, major new info)
- User explicitly requests a new version

On update, bump the version number and note what changed in the header.

**On every update, also (re)generate the Claude Code handoff** — a separate companion `.md` produced in its own tab, kept in sync with the brief (same version, refreshed content), always ready to paste into Claude Code. Present both outputs together. See the **Claude Code Handoff** section below for content rules.

---

## Brief Structure

### Always present:
- **Header** — Project name, tagline, version, date, key tags
- **Roadmap** — Phased plan, always present even if phases are approximate

### Include when relevant (adapt to project):
- Zaključane odluke — confirmed decisions, no longer debated
- Arhitekturalne napomene — key technical decisions with rationale
- Tech stack — tools, services, hosting
- DB Schema — if a database is involved
- Brend & Identitet — colors, fonts, naming, positioning
- Cenovnik — if pricing exists
- Troškovi — monthly/yearly cost breakdown
- Bezbednost — security checklist
- Todo lista — open items outside the roadmap

### Length calibration
Match brief size to project size. A small side project gets a lean brief (header, roadmap, a couple of sections). A large multi-phase product gets the full treatment. Do not pad a simple project into a giant document.

**Use accordion** within sections for items with long descriptions (roadmap phases, feature lists).
**Use tabs** when needed — for sections with clearly distinct sub-areas that shouldn't scroll past each other (e.g., a DB schema with many tables, or a multi-domain section).

---

## Versioning Convention

| Change type         | Version bump |
|---------------------|-------------|
| First brief         | v1.0        |
| Minor additions     | v1.1, v1.2… |
| Major restructure   | v2.0        |

Show version + date in header. On updates, add a line: *"Ažurirano: [šta je izmenjeno]"*

---

## File Naming

```
[project-slug]-brief-v[version].[ext]

Examples:
  venio-brief-v1.0.html
  my-app-brief-v2.1.pdf
  studio-project-brief-v1.0.jsx

Claude Code handoff companion:
  [project-slug]-claude-code-v[version].md
  venio-claude-code-v1.0.md
```

---

## Color System

### Brand colors (when provided)
Map the client's brand colors to these roles:
- `accent` → primary brand color: header gradient, section borders, tags, phase numbers
- `secondary` → secondary brand color: highlights, badges, alternate accents
- `light` → lightest brand color: backgrounds, subtle fills, hover states

### Only one brand color provided
Generate a small palette from it:
- `accent` → the brand color as-is
- `secondary` → a lighter or darker shade of the same color (adjust lightness ±20-30%)
- `light` → a very light tint of the brand color (for backgrounds)
- Add one contrasting color for alerts/variety (complementary hue)

### Default palette (when no brand colors provided)
```
accent:        #ffb447    golden orange
secondary:     #9fc0df    blue
light:         #dbe4ee    light blue
dark-header:   #0a1628 → #1a3a5c  (header gradient)
text:          #1a2a3a    dark body text
text-muted:    #8a9ab5    labels and secondary text
surface:       #ffffff    card backgrounds
border:        rgba(212,175,55,0.15)   subtle card borders
page-bg:       linear-gradient(135deg, #f8f5ee, #faf8f3, #f0eee8)
```

### Phase colors (rotate for visual variety)
```js
const PHASE_COLORS = [
  { color: "#2d6a4f", light: "rgba(45,106,79,0.08)",  border: "rgba(45,106,79,0.25)"  },
  { color: "#1a3a5c", light: "rgba(26,58,92,0.08)",   border: "rgba(26,58,92,0.25)"   },
  { color: "#5b2d8e", light: "rgba(91,45,142,0.08)",  border: "rgba(91,45,142,0.25)"  },
  { color: "#7a3d00", light: "rgba(122,61,0,0.08)",   border: "rgba(212,175,55,0.30)" },
]
// Cycle: i % PHASE_COLORS.length
```

---

## Fonts

Default: **Playfair Display** (headings, h1, section titles) + **DM Sans** (body).

Load via Google Fonts. In HTML, place in `<head>`:
```html
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
```

When the user provides brand fonts, substitute them and load the matching Google Fonts link (or a system-font fallback if the font isn't on Google Fonts).

---

## Shared Components (all formats)

Every brief is built from the same conceptual building blocks. Implement them per-format (CSS classes for HTML, inline-styled functions for JSX).

- **Section** — collapsible block with a colored left border (accent). Click title to toggle.
- **Row** — key-value pair. Label (muted, min-width ~180px) + value + optional badge.
- **Alert** — callout box. Types: tip (green), warning (yellow), info (blue), todo (orange), arch (purple). Icon + colored border + tinted bg.
- **Decided** — confirmed decision with green checkmark prefix.
- **Todo** — open item with orange square prefix.
- **Tag** — small pill chip, used in header and inline.
- **PhaseCard** — accordion card for roadmap. Closed: number, title, subtitle, task count. Open: task list with optional indented sub-items.
- **DBTable** — bordered table card (colored header + field rows) for DB schema sections.
- **CostRow** — service name + detail + monthly + yearly columns, for cost breakdown sections.

### Header pattern
Dark gradient background (`linear-gradient(160deg, #0a1628, #0d2040, #1a3a5c)`), rounded corners. Contains: small uppercase "PROJECT BRIEF" label in accent color, large project name (Playfair Display), subtitle + version + date line, and a row of tag chips.

### Roadmap summary footer
After all phase cards, render a compact list: total task count + phase count, then one line per phase (number — title — task count).

### Reference sections (bottom of long briefs)
For long briefs, place dense reference material (full tech stack, DB schema, full pricing, security checklist) in collapsible sections set to **closed by default**, grouped at the bottom. Keeps the top scannable while preserving detail.

---

## HTML Specification

Single self-contained `.html` file. All CSS and JS inline. Mobile-responsive.

### CSS variables (set on :root, override when brand colors provided)
```css
:root {
  --accent:     #ffb447;
  --secondary:  #9fc0df;
  --light:      #dbe4ee;
  --text:       #1a2a3a;
  --muted:      #8a9ab5;
  --surface:    #ffffff;
  --border:     rgba(212,175,55,0.15);
  --radius:     10px;
}
```

### Layout + mobile responsiveness
```css
.container { max-width: 880px; margin: 0 auto; padding: 40px 20px; }

@media (max-width: 640px) {
  .container { padding: 24px 14px; }
  h1 { font-size: 32px !important; }
  .row { flex-direction: column; gap: 2px; }
  .row .label { min-width: auto; }
  .phase-card .meta { flex-wrap: wrap; }
  .db-tables { overflow-x: auto; }  /* horizontal scroll for wide tables */
}
```

### Hover effects (simple, elegant)
All transitions `0.2s ease` unless noted.
```css
/* Section collapse */
.section-body { max-height: 0; overflow: hidden; transition: max-height 0.35s ease; }
.section-body.open { max-height: 9999px; }

/* Row highlight */
.row:hover { background: rgba(212,175,55,0.04); transition: background 0.2s ease; }

/* Phase card border accent */
.phase-card { border: 1px solid var(--border); transition: border-color 0.2s ease, box-shadow 0.2s ease; }
.phase-card:hover { border-color: var(--accent); box-shadow: 0 2px 12px rgba(0,0,0,0.06); }

/* Tag lift */
.tag { transition: transform 0.2s ease, box-shadow 0.2s ease; }
.tag:hover { transform: translateY(-1px); box-shadow: 0 3px 8px rgba(0,0,0,0.12); }

/* Animated underline on section headers */
.section-toggle { position: relative; display: inline-block; }
.section-toggle::after {
  content: ''; position: absolute; bottom: -2px; left: 0;
  width: 0; height: 1px; background: var(--accent); transition: width 0.25s ease;
}
.section-toggle:hover::after { width: 100%; }

/* Alert brightness */
.alert { transition: filter 0.2s ease; }
.alert:hover { filter: brightness(0.97); }

/* Decided / Todo icon color */
.decided-item:hover .icon { color: #16a34a; }
.todo-item:hover .icon    { color: #ea580c; }

/* Header tag color invert */
.header-tag { transition: background 0.2s ease, color 0.2s ease; }
.header-tag:hover { background: var(--accent); color: #0a1628; }
```

### JavaScript — accordion + tabs
```js
// Accordion toggle (sections + phase cards)
document.querySelectorAll('[data-toggle]').forEach(btn => {
  btn.addEventListener('click', () => {
    const target = document.getElementById(btn.dataset.toggle);
    const isOpen = target.classList.toggle('open');
    const arrow = btn.querySelector('.arrow');
    if (arrow) arrow.textContent = isOpen ? '▼' : '▶';
  });
});

// Tabs (only when a tabbed section is present)
document.querySelectorAll('.tab-group').forEach(group => {
  const tabs   = group.querySelectorAll('[data-tab]');
  const panels = group.querySelectorAll('[data-panel]');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      panels.forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      group.querySelector(`[data-panel="${tab.dataset.tab}"]`)?.classList.add('active');
    });
  });
});
```
```css
/* Tab styling */
.tab-group .tabs { display: flex; gap: 4px; border-bottom: 1px solid var(--border); margin-bottom: 16px; }
.tab-group [data-tab] {
  padding: 8px 16px; cursor: pointer; border: none; background: none;
  color: var(--muted); font-weight: 600; border-bottom: 2px solid transparent;
  transition: color 0.2s ease, border-color 0.2s ease;
}
.tab-group [data-tab]:hover { color: var(--text); }
.tab-group [data-tab].active { color: var(--accent); border-bottom-color: var(--accent); }
.tab-group [data-panel] { display: none; }
.tab-group [data-panel].active { display: block; }
```

---

## JSX Specification

Single `.jsx` file, saved for **download only** (not rendered as an artifact).

- Start with `import { useState } from "react";`
- End with `export default function [ProjectName]Brief() { ... }`
- All styles inline. Components use `useState` for collapse/accordion.
- Google Fonts loaded via a `<link>` element inside the returned JSX.
- Implement the shared components as inline-styled functions (Section, Row, Alert, Decided, Todo, Tag, PhaseCard, DBTable, CostRow).

---

## PDF Specification

Before generating, read `/mnt/skills/public/pdf/SKILL.md`.

Build the HTML version first, then convert with weasyprint:
```bash
pip install weasyprint --break-system-packages
python3 -c "
from weasyprint import HTML
HTML(filename='brief.html').write_pdf('brief.pdf')
"
```

Print overrides in the HTML:
```css
@media print {
  * { transition: none !important; }
  .section { page-break-inside: avoid; }
  .phase-card { page-break-inside: avoid; }
  .header { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .arrow, [data-toggle] { display: none; }
  .section-body { max-height: none !important; overflow: visible !important; }
}
```

---

## Markdown Specification

Plain `.md` file. No interactivity, but preserves structure:
- `#` project name + version/date line
- `##` per section
- Roadmap as `###` per phase with `-` task lists
- Decisions/todos as checkbox lists (`- [x]` / `- [ ]`)
- Tables for DB schema, pricing, costs
- Use `>` blockquotes for callouts (prefix with **Tip:**, **Napomena:**, etc.)

---

## Claude Code Handoff (companion .md)

A plain-text Markdown handoff that the user can paste into Claude Code when it's time to move project work there. It is **always a separate output in its own tab**, alongside the styled brief, never embedded in it.

**When to produce it:**
- Automatically on **every brief update** — refresh it so it tracks the latest version (same version number as the brief).
- On the first creation and at any time the user explicitly asks for the handoff.

**How to deliver it:**
- Save as a separate file: `[project-slug]-claude-code-v[version].md`.
- Present it as its own output (its own tab) so the user can open and copy the raw Markdown straight into Claude Code.
- Plain Markdown text only — no styling, no interactivity, nothing decorative.

**Content rules** (optimized for an AI coding agent to read and act on):
- **Start with an intro block** telling the agent what it's looking at and what to do:
  > "Ovo je kompletan project brief za [naziv]. Pročitaj ceo dokument pre nego što počneš. Krećemo sa Fazom 01. Pitaj ako nešto nije jasno pre kodiranja."
- Lead with the roadmap and confirmed decisions — the agent needs scope and constraints first.
- Be explicit and unambiguous: exact tech choices, file/URL conventions, naming rules, DB schema as tables.
- Include any architectural decisions with the *why*, so the agent doesn't undo them.
- Avoid purely decorative content — every line should inform implementation.
- Keep it self-contained: the agent should not need outside context to start work.

---

## Quality Checklist

Before presenting:
- [ ] Roadmap present, with real tasks per phase
- [ ] Brand colors applied (or default/derived palette used consistently)
- [ ] Accordion / tabs work
- [ ] Version and date visible in header
- [ ] Saved as a file with correct naming (claude.ai outputs + `present_files`, or project dir in Claude Code), NOT a React artifact
- [ ] On update: Claude Code handoff `.md` refreshed in its own tab
