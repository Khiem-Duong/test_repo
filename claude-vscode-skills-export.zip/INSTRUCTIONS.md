# Claude Code Skills & Plugins — Install Instructions

This archive was exported from another machine running Claude Code (CLI) and contains a curated set of design/UI-focused Skills, plus a list of Plugins to install from their official marketplaces. It is meant to be handed to a **Claude Code instance running inside VS Code** so that instance can replicate the same setup.

If you are Claude Code reading this file: please perform the installation steps below yourself, using your Bash tool. Do not just summarize this file back to the user — actually copy the files and run the commands.

## 1. Scope and intent

- Everything in this archive must be installed **globally** at user scope (`~/.claude/skills/` for Skills, `--scope user` for Plugins) — **never** project-scoped. This mirrors the source machine's setup so the same Skills/Plugins are available across all projects, not just the current one.
- Do not overwrite any existing skill folder of the same name without first diffing it — if the destination already has a folder with the same name and different content, ask the user whether to overwrite, keep both, or skip.

## 2. What's in `skills/`

This folder contains **73 plain Skill folders** (each is a self-contained directory with a `SKILL.md`, and sometimes supporting files like `data/`, `scripts/`, `references/`, or a `DESIGN.md`). These do not require any marketplace — they are just files.

- 67 folders named `design-<slug>` (e.g. `design-cafe`, `design-minimal`, `design-brutalism`, `design-impeccable`, ...) — a full catalog of design-system style guides from the `bergside/awesome-design-skills` project (verify exact org name if reinstalling fresh; these were copied directly, not cloned via marketplace). Each defines a distinct visual/brand aesthetic (typography, color tokens, spacing, component rules) that can be invoked by name, e.g. "use the design-impeccable skill" or "apply design-brutalism to this page."
- `ui-ux-pro-max` — general UI/UX design assistant skill (source: `nextlevelbuilder/ui-ux-pro-max-skill`).
- `premium-frontend-ui` — frontend UI patterns (source: GitHub's `awesome-copilot` repo, `skills/premium-frontend-ui` path).
- `mobile-app-ui-design` — mobile app UI guidance (source: `ceorkm/mobile-app-ui-design`).
- `material-3` — Material Design 3 guidance (source: `hamen/material-3-skill`).
- `swiftui-pro` — SwiftUI-specific design/implementation guidance (source: `twostraws/swiftui-agent-skill`).

### Install command for `skills/`

```bash
cp -R skills/* ~/.claude/skills/
```

After copying, the skills are auto-discovered by Claude Code — no restart or registration step is required. They become invocable immediately via the Skill tool or by naming them in a prompt (e.g. "use the ui-ux-pro-max skill").

## 3. Plugins (not included as files — install from marketplace instead)

Two plugins were also added on the source machine. Plugin caches are tied to marketplace metadata on the original machine and should not be copied as raw files — install them fresh from their official marketplaces instead, which is fast and guarantees a clean, current copy:

```bash
claude plugin marketplace add greensock/gsap-skills
claude plugin install gsap-skills@gsap-skills --scope user

claude plugin marketplace add expo/skills
claude plugin install expo@expo-plugins --scope user
```

- `gsap-skills` — GSAP animation library skills (core, frameworks, performance, plugins, react, scrolltrigger, timeline, utils).
- `expo` — Expo/React Native UI and tooling skills.

## 4. Verification

After installing, confirm everything is present:

```bash
ls ~/.claude/skills/ | grep -c design-     # should print 67
claude plugin list                          # should show gsap-skills and expo as enabled, scope user
```

## 5. Naming collision note

If this machine already has a skill literally named `impeccable` (different from `design-impeccable`), that is expected and intentional — they come from different authors/sources. Do not merge or delete either one; both are meant to coexist under their distinct names.

## 6. Maintenance going forward

These Skills are plain file copies with no built-in update mechanism on this machine. To check for upstream updates later, re-clone the relevant source repo (see "source:" notes above) and diff against the locally installed folder, copying over only files that differ. Some of these skills (e.g. the `design-*` catalog, `design-motion-principles` if present) may also be tracked by the third-party `skills` CLI (`npx skills update -g -y`) if it is installed and the source machine used it to add them — check `~/.agents/.skill-lock.json` for tracked sources before doing a manual diff.
